// Branding centralisé pour l'app mobile (Expo)
export const BRAND_NAME = 'FleetChecks';
// Logo PNG distant (même que le web, sert aussi dans les templates PDF HTML)
export const BRAND_LOGO_URL = 'https://i.ibb.co/xqf1LCDC/Chat-GPT-Image-6-sept-2025-01-04-56.png';

export default { BRAND_NAME, BRAND_LOGO_URL };
