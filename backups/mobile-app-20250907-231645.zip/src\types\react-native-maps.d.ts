declare module 'react-native-maps';
