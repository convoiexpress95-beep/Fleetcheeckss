export const WEB_BASE_URL = process.env.EXPO_PUBLIC_WEB_BASE_URL || '';
