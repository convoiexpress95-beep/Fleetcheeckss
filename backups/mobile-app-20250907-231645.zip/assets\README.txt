Put your app icons and splash images here.
Expected:
- icon.png (1024x1024)
- adaptive-icon.png (foreground for Android)
- splash.png (portrait-friendly)
- notification-icon.png (optional)
